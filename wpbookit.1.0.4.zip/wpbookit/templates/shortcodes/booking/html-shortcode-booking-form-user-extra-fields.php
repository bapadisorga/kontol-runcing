<div class="col-12">
    <?php do_action('wpb_after_user_detail_field',$args['shortcode_instance']); ?>
</div>