<?php

defined('ABSPATH') || exit;

do_action('wpb_booking_shortcode_form', $args); 

do_action('wpb_after_bookingmodal',$args);
