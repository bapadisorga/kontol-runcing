<?php

/**
 * Dashboard Layout
 *
 * Override to change in button
 * 
 * @version 1.0.4
 */

defined('ABSPATH') || exit;

?>
<div class="wpbookit-dashboard">
   Main Content
</div>